These files are examples of output obtained for the small dataset for the three first tasks with a k of 5, a f (minimum frequency) of 5 and 4 folds (when applicable).
